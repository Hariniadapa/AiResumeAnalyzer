import json
import os

DATA_PATH = os.path.join("data", "linkedin_jobs.json")

def load_jobs():
    if not os.path.exists(DATA_PATH):
        return []

    with open(DATA_PATH, "r", encoding="utf-8") as f:
        return json.load(f)

def match_jobs(resume_skills):
    jobs = load_jobs()
    recommendations = []

    resume_skills = [s.lower() for s in resume_skills]

    for job in jobs:
        job_skills = [s.lower() for s in job.get("skills", [])]
        matched = set(resume_skills).intersection(job_skills)

        if matched:
            recommendations.append({
                "title": job["title"],
                "companyName": job["companyName"],
                "location": job["location"],
                "link": job["link"],
                "matched_skills": list(matched),
                "match_score": f"{len(matched)}/{len(job_skills)}"
            })

    return recommendations
