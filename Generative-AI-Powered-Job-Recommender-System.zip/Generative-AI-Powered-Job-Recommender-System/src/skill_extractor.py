from groq import Groq
import os

client = Groq(api_key=os.getenv("GROQ_API_KEY"))

def extract_skills(resume_text):
    prompt = f"""
    Extract technical skills from the resume below.
    Return only a Python list.

    Resume:
    {resume_text}
    """

    response = client.chat.completions.create(
        model="llama-3.1-8b-instant",
        messages=[{"role": "user", "content": prompt}],
        temperature=0.2,
        max_tokens=200
    )

    skills = response.choices[0].message.content
    return eval(skills)
