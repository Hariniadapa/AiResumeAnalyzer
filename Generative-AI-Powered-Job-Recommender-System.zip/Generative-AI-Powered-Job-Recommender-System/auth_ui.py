import streamlit as st
from auth import create_user, login_user

def render_auth_ui():

    st.markdown("<div class='auth-card'>", unsafe_allow_html=True)
    st.markdown("<div class='auth-title'>AI Job Recommender</div>", unsafe_allow_html=True)

    tab_login, tab_signup = st.tabs(["Login", "Signup"])

    # Login
    with tab_login:
        username = st.text_input("Username", key="login_user")
        password = st.text_input("Password", type="password", key="login_pass")

        if st.button("Login", key="login_btn"):
            if login_user(username, password):
                st.session_state.logged_in = True
                st.session_state.username = username
                st.rerun()
            else:
                st.error("Invalid username or password")

    # Signup
    with tab_signup:
        new_user = st.text_input("Username", key="signup_user")
        new_pass = st.text_input("Password", type="password", key="signup_pass")

        if st.button("Create Account", key="signup_btn"):
            if create_user(new_user, new_pass):
                st.success("Account created. Please login.")
            else:
                st.error("Username already exists")

    st.markdown("</div>", unsafe_allow_html=True)
