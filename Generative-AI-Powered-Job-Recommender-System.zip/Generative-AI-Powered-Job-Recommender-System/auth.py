import sqlite3
import bcrypt

# ---------------- Database Connection ----------------
conn = sqlite3.connect("users.db", check_same_thread=False)
cursor = conn.cursor()

# ---------------- Users Table ----------------
cursor.execute("""
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE,
    password BLOB
)
""")
conn.commit()

# ---------------- Resume History Table ----------------
cursor.execute("""
CREATE TABLE IF NOT EXISTS resume_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT,
    resume_text TEXT,
    summary TEXT,
    ats_score INTEGER,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)
""")
conn.commit()

# ---------------- Resume Functions ----------------
def save_resume(username, resume_text, summary, ats_score):
    print("Inside save_resume function")
    cursor.execute(
        "INSERT INTO resume_history (username, resume_text, summary, ats_score) VALUES (?, ?, ?, ?)",
        (username, resume_text, summary, ats_score)
    )
    conn.commit()
    print("Resume saved successfully")


def get_resume_history(username):
    cursor.execute(
        "SELECT summary, created_at, ats_score FROM resume_history WHERE username=? ORDER BY created_at DESC",
        (username,)
    )
    return cursor.fetchall()  # Returns list of tuples: (summary, created_at, ats_score)

# ---------------- User Functions ----------------
def create_user(username, password):
    hashed = bcrypt.hashpw(password.encode(), bcrypt.gensalt())
    try:
        cursor.execute(
            "INSERT INTO users (username, password) VALUES (?, ?)",
            (username, hashed)
        )
        conn.commit()
        return True
    except sqlite3.IntegrityError:
        return False

def login_user(username, password):
    cursor.execute("SELECT password FROM users WHERE username=?", (username,))
    result = cursor.fetchone()
    if result and bcrypt.checkpw(password.encode(), result[0]):
        return True
    return False
