from flask import Flask, render_template, request, redirect, session
from auth import create_user, login_user, save_resume, get_resume_history
from src.helper import extract_text_from_pdf, ask_openai
from src.job_matcher import match_jobs
import os

app = Flask(__name__)
app.secret_key = "supersecretkey"   # change later


# ---------------- ATS Score ----------------
def calculate_ats_score(resume_text):
    keywords = [
        "python", "java", "sql", "machine learning",
        "data analysis", "project", "internship",
        "bachelor", "degree", "certification"
    ]
    resume_lower = resume_text.lower()
    matched = sum(1 for k in keywords if k in resume_lower)
    return int((matched / len(keywords)) * 100)


# ---------------- LOGIN PAGE ----------------
@app.route("/")
def home():
    return render_template("home.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]

        if login_user(username, password):
            session["user"] = username
            return redirect("/dashboard")
        else:
            return render_template("login.html", error="Invalid credentials")

    return render_template("login.html")



# ---------------- SIGNUP ----------------
@app.route("/signup", methods=["POST"])
def signup():
    username = request.form["username"]
    password = request.form["password"]

    if create_user(username, password):
        return redirect("/")
    else:
        return render_template("login.html", error="User already exists")


# ---------------- DASHBOARD ----------------
@app.route("/dashboard", methods=["GET", "POST"])
def dashboard():

    if "user" not in session:
        return redirect("/login")

    ats_score = None
    summary = None
    skills = []
    gaps = None
    tips = None
    roadmap = None
    jobs = []

    history = get_resume_history(session["user"])

    if request.method == "POST":
        resume = request.files.get("resume")

        if resume and resume.filename != "":
            text = extract_text_from_pdf(resume)

            summary = ask_openai("Give professional summary:\n\n" + text)
            skills_text = ask_openai("Extract technical skills:\n\n" + text)
            gaps = ask_openai("Find skill gaps:\n\n" + text)
            tips = ask_openai("Give resume improvement tips:\n\n" + text)
            roadmap = ask_openai("Create career roadmap:\n\n" + text)

            ats_score = calculate_ats_score(text)

            skills = [s.strip() for s in skills_text.split(",")]

            # Save to database
            save_resume(session["user"], text, summary, ats_score)

            # Refresh history
            history = get_resume_history(session["user"])

    return render_template(
        "dashboard.html",
        ats_score=ats_score,
        summary=summary,
        skills=skills,
        gaps=gaps,
        tips=tips,
        roadmap=roadmap,
        jobs=jobs,
        history=history
    )





    




# ---------------- LOGOUT ----------------
@app.route("/logout")
def logout():
    session.pop("user", None)
    return redirect("/")


if __name__ == "__main__":
    app.run(debug=True)
